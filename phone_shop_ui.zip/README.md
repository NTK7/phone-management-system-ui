# Frontend for a phone management website

- run 

        npm install

        npm start       