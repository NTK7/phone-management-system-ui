import './Footer.css';

function Footer() {
	return (
		<div className="footer">
			<p>©Phone Shop Name</p>
		</div>
	);
}

export default Footer;
